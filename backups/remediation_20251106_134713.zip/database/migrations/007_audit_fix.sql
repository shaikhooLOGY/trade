-- Migration 007: Audit Trail Schema Alignment
-- Authoritative Audit Events Table Implementation
-- Created: 2025-11-06
-- Description: Creates/updates audit_events table to match authoritative schema

-- Drop existing table if it exists to start fresh with correct schema
DROP TABLE IF EXISTS audit_events;

-- Create new audit_events table with authoritative schema
CREATE TABLE audit_events (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    actor_id BIGINT NOT NULL,
    action VARCHAR(100) NOT NULL,
    entity VARCHAR(50) NOT NULL,
    entity_id BIGINT NULL,
    summary TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_actor_id (actor_id),
    INDEX idx_action (action),
    INDEX idx_entity (entity),
    INDEX idx_created_at (created_at),
    INDEX idx_actor_action (actor_id, action),
    INDEX idx_entity_type (entity, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT="Authoritative audit events table";

-- Verify table creation
SELECT 'Migration 007: Audit trail schema alignment completed successfully' as result;